# MAMAZEE WEARS

## An Ecommerce personal project

## Built with NODEJS, EXPRESS, MONGODB

View live link below
[www.mamazee.com](https://mamazee.netlify.app).

![Mamazee wears](https://res.cloudinary.com/devsource/image/upload/v1614948495/portfolio/admn_ubw1pr.png)

## Project by Layobright
